<script setup>
import {Text} from '@/components/ui/text';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
</script>
<template>
    
  <main class="px-8 w-full">
    <section>
        <div class="section-header mb-10">
            <Text type="h2">Prompts</Text>
            <Text type="p">Your prompts collection</Text>
        </div>
        <div class="section-body">
        </div>
    </section>
  </main>
</template>