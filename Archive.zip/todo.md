# TODO 

- [x] Read PDF
- [ ] Feed with pdf
- [ ] Save read result of pdf to IndexedDB
- [ ] Choose model
- [ ] List model 
- [ ] Check if model have been downloaded or not
- [ ] PWA support